> # Culturama:

> ### Sobre:
Uma plataforma Web e Mobile que visa incentivar o turismo, cultura, locais, hoteis de uma região. Terá a possibilidade de buscar e indicar locais, também contratar guia turísticos.

> ### Protótipo

[Figma](https://www.figma.com/design/vFauTIfcBFC2lo5Dw0OkHM/CULTURAMA?node-id=0-1&t=fDZwKGLLjCGjZuIO-1)
